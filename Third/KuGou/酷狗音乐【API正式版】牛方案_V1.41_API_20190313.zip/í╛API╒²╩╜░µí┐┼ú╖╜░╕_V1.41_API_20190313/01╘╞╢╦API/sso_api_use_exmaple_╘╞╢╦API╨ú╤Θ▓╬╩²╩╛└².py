#!/usr/bin/python3

#1 将公共参数以及其他api参数的参数值外加appkey进行utf8编码后进行字典序排序；
#2 将排序后的数据拼接成一个字符串，拼接时不要任何分隔符，进行MD5加密；
#3 将加密后的字节流转换成十六进制，然后赋值给signature字段；
#4 非int，string类型参数不参与计算签名；

import requests
import time
import uuid
import hashlib
import json

APPKEY  = "apple"
HOST    = "https://thirdsso.kugou.com"
HEADERS = {
    "appid"     : 10086,
    "uuid"      : "111122223333",   #硬件设备唯一标示，由接口使用方提供
    "mid"       : "111122223333",   #手机端唯一标示符，由接口使用方提供
    "timestamp" : int(time.time()), #unix时间戳
    "nonce"     : uuid.uuid4().hex, #随机字串
}

def _get_signature(headers, data):
    # 合并所有的参数
    args = {}
    args.update(headers)
    args.update(data)

    # 获取所有的参数值
    values = list(args.values())

    # 加入appkey
    values.append(APPKEY)

    # 将所有参数转换为string类型, 同时编码（utf8）
    values = [str(k).encode("utf8") for k in values]

    # 做字典排序
    values.sort()

    # 拼接byte数组
    signature = b"".join(values)

    # 计算MD5
    md5 = hashlib.md5()
    md5.update(signature)
    signature =  md5.hexdigest()
    signature = signature.encode("utf8")
    return signature

def search_song():
    data = {
        "keyword": "春",
        "page": 1,
        "pagesize": 1,
        "platform": "WebFilter",
        "PrivilegeFilter": 1
    }
    path = "/v1/search/song_search"
    headers = dict(HEADERS)
    headers["userid"] = "10086"
    headers["token"] =  "123456"
    signature = _get_signature(headers, data)
    # 计算出的signature值为b4d469b67133c059df0b2c2d659494ff
    headers["signature"] = signature
    headers["Content-Type"] = "application/json"
    rtn = requests.post(HOST+path, headers=headers, data=json.dumps(data))
    print(rtn.text)

if __name__ == "__main__":
    search_song()
